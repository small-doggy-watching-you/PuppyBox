import Alamofire
import Foundation

final class DataService {
    private let upcomingURL = "https://api.themoviedb.org/3/movie/upcoming"
    func fetchData(pageNum: Int, completion: @escaping (Result<MovieData, Error>) -> Void) {
        let parameters: Parameters = [
            "language": "ko-kr",
            "page": pageNum,
        ]

        let headers: HTTPHeaders = [
            "accept": "application/json",
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI4NDI3YmQwZDFjOGRmOGM4MTcxNmJlNTE5Yjg1NjNhNiIsIm5iZiI6MTc1MjU1MzcxOC40OTIsInN1YiI6IjY4NzVkOGY2NTAwMDBhZmI0OGQxNWZiZCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.JFYjuO57eOIw4mNjUuuUAQa_R0I3GYSwKrMBukP5sgQ",
        ]

        AF.request(upcomingURL, method: .get, parameters: parameters, headers: headers)
            .responseDecodable(of: MovieData.self) { response in
                switch response.result {
                case let .success(data):
                    completion(.success(data))
                case let .failure(error):
                    completion(.failure(error))
                }
            }
    }
}
